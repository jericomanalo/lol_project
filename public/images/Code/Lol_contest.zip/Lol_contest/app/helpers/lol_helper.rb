module LolHelper
end
