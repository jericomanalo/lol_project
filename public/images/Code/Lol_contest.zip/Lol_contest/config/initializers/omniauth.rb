OmniAuth.config.logger = Rails.logger

Rails.application.config.middleware.use OmniAuth::Builder do
	provider :facebook, '643653609119486', 'adb54e6423c0ba2450c29cb51a0f3069', {:client_options => {:ssl => {:ca_file => Rails.root.join("cacert.pem").to_s}}}	
end