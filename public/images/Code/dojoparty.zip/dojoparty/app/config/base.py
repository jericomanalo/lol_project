"""
    Base Configuration File
"""
""" Put Generic Configurations here """
class Config(object):
    DEBUG = False
    TESTING = False
    SECRET_KEY = 'someSecretKey'
    CLIENT_ID = 'fb88444a7137f351db0974a27b7278e3'
    CLIENT_SECRET = '47dff4dbc69746ac99bb888fd000f24a'

""" Put Development Specific Configurations here """
class DevelopmentConfig(Config):
    DEBUG = True

""" Put Staging Specific Configurations here """
class StagingConfig(Config):
    TESTING = True

""" Put Production Specific Configurations here """
class ProductionConfig(Config):
    pass
