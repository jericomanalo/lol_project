#config/initializers/constants.rb
#indicate your app id and secret key provided by Facebook
APP_ID = '643653609119486'
APP_SECRET = 'adb54e6423c0ba2450c29cb51a0f3069'
SITE_URL = 'https://localhost:3000'
