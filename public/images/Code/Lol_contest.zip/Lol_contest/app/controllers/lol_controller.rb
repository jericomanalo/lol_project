class LolController < ApplicationController
  require 'json'
  require 'net/http' #to make a GET request
  require 'open-uri' #to fetch the data from the URL to then be parsed by JSON
    $lol_key = "b8a84394-c482-433d-a426-5db7d03615fc"
    $lol_uri = "https://global.api.pvp.net"
    $summoner_uri = "https://na.api.pvp.net"
    def index

    end

 def get_summoner_profile
     summoner_query = "/api/lol/na/v1.4/summoner/by-name/timithicus?api_key="
     champ_mast_query = "/championmastery/location/na1/player/20881900/champions?api_key="

     uri = URI.parse($summoner_uri+summoner_query+$lol_key)
     http = Net::HTTP.new(uri.host, uri.port)
     http.use_ssl = true
     http.verify_mode = OpenSSL::SSL::VERIFY_NONE
     request = Net::HTTP::Get.new(uri.request_uri)
     response = http.request(request)
     #store the body of the requested URI (Uniform Resource Identifier)
     data = response.body
     #to parse JSON string; you may also use JSON.parse()
     #JSON.load() turns the data into a hash
     @summoner = []
     @lol = JSON.load(data)
     @lol.each do |this|
     @summoner.push(this[0])

     champ_uri = URI.parse($summoner_uri+champ_mast_query+$lol_key)
     champ_http = Net::HTTP.new(champ_uri.host, champ_uri.port)
     champ_http.use_ssl = true
     champ_http.verify_mode = OpenSSL::SSL::VERIFY_NONE
     champ_request = Net::HTTP::Get.new(champ_uri.request_uri)
     champ_response = champ_http.request(champ_request)
     #store the body of the requested URI (Uniform Resource Identifier)
     champ_data = champ_response.body
     #to parse JSON string; you may also use JSON.parse()
     #JSON.load() turns the data into a hash
     @champion_masteries = JSON.load(champ_data)


     # render :text => data
 end
end
end
